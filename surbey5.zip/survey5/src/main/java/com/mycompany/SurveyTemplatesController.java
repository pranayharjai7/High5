
package com.mycompany;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;




public class SurveyTemplatesController  
{

 @FXML
    private Label SurveyTemplateLabel;

    @FXML
    private Button SportsAndFitness;

    @FXML
    private Button FoodAndNutritionButton;

 
    @FXML
    void SportsAndFitnessButtonClicked(ActionEvent event) throws IOException{
        App.setRoot("SportsAndFitness");

    }

    @FXML
    void FoodAndNutritionButtonClicked(ActionEvent event) throws IOException{
        App.setRoot("Food&Nutrition");
    }

 
}
